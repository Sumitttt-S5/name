from setuptools import setup

setup(name="demo", version="1.0.0")
